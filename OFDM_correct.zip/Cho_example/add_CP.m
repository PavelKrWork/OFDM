function y=add_CP(x,Ng)
% Add CP (Cyclic Prefix) of length Ng
y = [x(:,end-Ng+1:end) x];