function y=remove_CP(x,Ng,Noff)
% Remove CP (Cyclic Prefix) of length Ng
if nargin<3, Noff=0; end
y=x(:,Ng+1-Noff:end-Noff);