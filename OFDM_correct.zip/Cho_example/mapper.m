function [modulated_symbols, Mod] = mapper(b, N)
    % Если N задан, генерирует блок из N случайных 2^b-PSK/QAM модулированных символов
    % Иначе, генерирует блок 2^b-PSK/QAM модулированных символов для [0:2^b-1].
    
    M = 2^b; % Порядок модуляции или размер алфавита (количество символов)
    
    if b == 1
        Mod = 'BPSK';
        A = 1;
        mod_object = comm.PSKModulator(M, 'PhaseOffset', pi/4);
    elseif b == 2
        Mod = 'QPSK';
        A = 1;
        mod_object = comm.PSKModulator(M, 'PhaseOffset', pi/4);
    else
        Mod = [num2str(M) 'QAM'];
        Es = 1;
        A = sqrt(3/(2*(M-1))*Es);
        mod_object = comm.QAMModulator(M, 'SymbolMapping', 'Gray');
    end
    
    if nargin == 2 % Блок из N случайных 2^b-PSK/QAM модулированных символов
        data = randi([0 M-1], 1, N); % Генерация случайных данных
        modulated_symbols = A * step(mod_object, data.'); % Модуляция
    else
        data = 0:M-1; % Данные для полного алфавита
        modulated_symbols = A * step(mod_object, data.'); % Модуляция
    end
end